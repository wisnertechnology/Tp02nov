import random
import string


#1- kreye yon fonksyon ki ap pran yon paramèt yon mo, epi li retounen envès la.
def enves_mo(mo):
    print("#1- kreye yon fonksyon ki ap pran yon paramèt yon mo, epi li retounen envès la.")
    nouvo_mo = ''
    for i in range(len(mo)-1, -1, -1):
        nouvo_mo += mo[i]
    return nouvo_mo
print(enves_mo("karaktè"))

print("\n\n\t\t ***************************************************\n\n")


#2- kreye yon fonksyon ki pou jenere yon kòd aleyatwa ki gen n karaktè alfabetik.
def kod_aleyatwa(n):
    print("#2- kreye yon fonksyon ki pou jenere yon kòd aleyatwa ki gen n karaktè alfabetik.")
    karakte = string.ascii_letters
    chenn_aleyatwa = ''.join(random.choice(karakte) for _ in range(n))
    return chenn_aleyatwa

print(kod_aleyatwa(10))

print("\n\n\t\t ***************************************************\n\n")


#3- kreye yon fonksyon ki pou jenere yon kòd aleyatwa ki gen n karaktè alfabetik, san repetisyon.
def kod_di_aleyatwa(n):
    print("#3- kreye yon fonksyon ki pou jenere yon kòd aleyatwa ki gen n karaktè alfabetik, san repetisyon.")
    karakte = list(string.ascii_letters)
    if n > len(karakte):
        raise ValueError("nonb karakte ou mande a depase")
    chenn_aleyatwa = random.sample(karakte, n)
    '''
        chenn_aleyatwa = random.sample(karakte, n)
            liy saa itilize fonksyon ' random.sample() ' laaa pou seleksyone ' n ' karakte aleyatwa nan lis ' karakte '. epi li garanti
                        ke pa gen okenn eleman kap repete plis ke yon fwa
                        
    '''          
    return ''.join(chenn_aleyatwa)
print(kod_di_aleyatwa(32))
print("\n\n\t\t ***************************************************\n\n")

#4- kreye yon fonksyon ki pou jenere yon kòd aleyatwa ki gen n karaktè alafanimerik, san repetisyon.
def kod_alfaNum(n):
    print("#4- kreye yon fonksyon ki pou jenere yon kòd aleyatwa ki gen n karaktè alafanimerik, san repetisyon.")
    karakte = string.ascii_letters + string.digits
    if n > len(karakte):
        raise ValueError("nonb karakte ou mande a depase")
    chenn_aleyatwa = random.sample(karakte, n)      # laaa li retounen pou nou yon lis
    print(chenn_aleyatwa)
    return ' '.join(chenn_aleyatwa)
print(kod_alfaNum(52))
print("\n\n\t\t ***************************************************\n\n")

#5- Ou gen yon lis chenn. Jenere yon SLUG apati chenn nan. Nan yon SLUG, tout karaktè ki akseptab yo se: alfanimerik ak "-"












#6- Kreye yon fonksyon ki ap separe chak lèt nan yon mo ak yon vigil

def separe_pa_vigil(mo):
    print("#6- Kreye yon fonksyon ki ap separe chak lèt nan yon mo ak yon vigil")
    let = ','.join(mo)
    return let
print(separe_pa_vigil("bonswa"))
print("\n\n\t\t ***************************************************\n\n")



#7- Kreye yon fonksyon ki ap kripte yon mo, avèk endèks li nan alfabè a. Chak karaktè dwe separe ak yon tirè.

#           >>> "ALO"
#           >>> "0-11-14"

def kripte_mo(mo):
    print("#7- Kreye yon fonksyon ki ap kripte yon mo, avèk endèks li nan alfabè a. Chak karaktè dwe separe ak yon tirè.\n\t\t>>> \"ALO\"\n\t\t>>> \"0-11-14\"")
    let_alfabe = "abcdefghijklmnopqrstuvwxyz"
    chif = ''
    
    for let in mo.lower():
        if let in let_alfabe:
            endeks = let_alfabe.index(let)
            chif += str(endeks) + "-"
    return chif[:-1]
    
print(kripte_mo("byenvini"))
print("\n\n\t\t ***************************************************\n\n")


#8- Kreye yon fonksyon ki ap dekripte yon mo ki fèt ak endèks chak lèt nan alfabè a, separe ak yon tirè.

#       >>> "0-11-14"
#       >>> "ALO"

def dekripte_mo(mo):
    print("#8- Kreye yon fonksyon ki ap dekripte yon mo ki fèt ak endèks chak lèt nan alfabè a, separe ak yon tirè.\n\t\t>>> \"0-11-14\"\n\t\t>>> \"ALO\"")
    let_alfabe = "abcdefghijklmnopqrstuvwxyz"
    endis = mo.split("-")
    mo_dekripte = ""
    
    
    for endeks_str in endis:
        endeks = int(endeks_str)
        if 0 <= endeks < len(let_alfabe):
            mo_dekripte += let_alfabe[endeks].upper()
            
            
            #print(endeks_str)
    return mo_dekripte
        

print(dekripte_mo("1-15-22-4-25"))
print("\n\n\t\t ***************************************************\n\n")




#9- Kreye yon fonksyon ki ap pran 2 paramèt, epi ki pèmite valè yo. Answit li retounen tou 2 valè yo sou fòm Tuple.

def vale_tip(val1, val2):
    print("#9- Kreye yon fonksyon ki ap pran 2 paramèt, epi ki pèmite valè yo. Answit li retounen tou 2 valè yo sou fòm Tuple.")
    return val1, val2
    
rezilta = vale_tip(13, "bierre")
print(rezilta)

print("\n\n\t\t ***************************************************\n\n")


#10- Kreye yon fonksyon ki ap pran yon non an paramèt, epi ki retounen inisyal yo. Atansyon ak non konpoze ak tirè yo.

'''```
 >>> "Jean-Baptiste Jean"
 >>> "JBJ"
'''

def inisyal(non):
    print("#10- Kreye yon fonksyon ki ap pran yon non an paramèt, epi ki retounen inisyal yo. Atansyon ak non konpoze ak tirè yo.")
    words = non.split()
    initiales = ''
    
    for word in words:
        initiales += word[0].upper()
        
    return initiales
    
reziltaa = inisyal("Jean Baptiste Alexandre")
print(reziltaa)
