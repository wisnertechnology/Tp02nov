#1- Ou gen yon diksyonè. Rekipere tout valè yo, gras ak kle yo epi retounen yon lis valè.
print("#1- Ou gen yon diksyonè. Rekipere tout valè yo, gras ak kle yo epi retounen yon lis valè.")
diksyone = {32:"laj", "non":"Pierre", "telephone":"32345678", "adres":"maryani_4", "a":11111, "b":22222}
lis_vale = list(diksyone.values())
print(lis_vale)
print("\n\n\t\t ***************************************************\n\n")



#2- Mande itilizatè a, tape yon valè... epi verifye si l gen akolad devan ak dèyè.
print("#2- Mande itilizatè a, tape yon valè... epi verifye si l gen akolad devan ak dèyè.")
vale_itilizate = input("tape yon vale ::: \t")
if vale_itilizate.startswith("{") and vale_itilizate.endswith("}"):
    print("li gen akolad devanl ak deyel")
else:
    print("li pa gen akolad devanl ak deyel")
    
print("\n\n\t\t ***************************************************\n\n")


#3- Pakouri yon diksyonè, epi afiche tout kle yo.
print("#3- Pakouri yon diksyonè, epi afiche tout kle yo.")
for i in diksyone:
    print(i)

print("\n\n\t\t ***************************************************\n\n")



#4- Pakouri yon diksyonè, epi afiche tout valè yo.
print("#4- Pakouri yon diksyonè, epi afiche tout valè yo.")
for i in diksyone.values():
    print(i)
print("\n\n\t\t ***************************************************\n\n")





#5- Pakouri yon diksyonè, pou w kapab kreye yon kopi(nouvo) sou disksyonè sa.
print("#5- Pakouri yon diksyonè, pou w kapab kreye yon kopi(nouvo) sou disksyonè sa.")
diksyone2 = diksyone.copy()
print(diksyone2)
print("\n\n\t\t ***************************************************\n\n")



#6- Anndan yon diksyonè ki gen kle ak valè(valè yo ka nenpòt tip done). Ajoute yon underscore devan ak dèyè tout valè ki se chenn yo. Ekzanp:

#           >>> {"name": "Lub", "age": 14, "assets": ["laptop", "phone"]}
#           >>> {"name": "_Lub_", "age": 14, "assets": ["laptop", "phone"]}

print("#6- Anndan yon diksyonè ki gen kle ak valè(valè yo ka nenpòt tip done). Ajoute yon underscore devan ak dèyè tout valè ki se chenn yo. Ekzanp\n\t\t>>> {\"name\": \"Lub\", \"age\": 14, \"assets\": [\"laptop\", \"phone\"]}\n\t\t>>> {\"name\": \"_Lub_\", \"age\": 14, \"assets\": [\"laptop\", \"phone\"]}")
diksyone3 = {}
for kle, vale in diksyone.items():
    if isinstance(vale, str):
        diksyone3[kle] = "_{}_".format(vale)
    else:
        diksyone3[kle] = vale
print(diksyone3)

print("\n\n\t\t ***************************************************\n\n")



#7- Nan yon diksyonè ki gen valè ki se chenn sèlman. Kreye yon nouvo diksyonè ki gen tout eleman ki gen valè ki dijit yo sèlman. Ekzanp:

#           >>> {"a": "12", "b": "abc", "c": "12r", "d":"90"}
#           >>> {"a": "12", "d":"90"}
print("#7- Nan yon diksyonè ki gen valè ki se chenn sèlman. Kreye yon nouvo diksyonè ki gen tout eleman ki gen valè ki dijit yo sèlman. Ekzanp:\n\t\t>>> {\"a\": \"12\", \"b\": \"abc\", \"c\": \"12r\", \"d\":\"90\"}\n\t\t>>> {\"a\": \"12\", \"d\":\"90\"}")
diksyone = {32:"laj", "non":"Pierre", "telephone":"32345678", "adres":"maryani_4", "a":"11111", "b":"22222b"}

diksyone_dijit = {}
for kle, vale in diksyone.items():
    if vale.isdigit():
        diksyone_dijit[kle] = vale
print(diksyone_dijit)
print("\n\n\t\t ***************************************************\n\n")







#8- Pakouri yon disksyonè, pou w mete l sou fòm lis, kote chak eleman nan disksyonè sa, vin sou fòm tipl(kle, valè) anndan lis la. Ekzanp:

#               >>> {"a":1, "b": 2}
#               >>> [("a",1), ("b",2)]
print("#8- Pakouri yon disksyonè, pou w mete l sou fòm lis, kote chak eleman nan disksyonè sa, vin sou fòm tipl(kle, valè) anndan lis la. Ekzanp:\n\t\t>>> {\"a\":1, \"b\": 2}\n\t\t>>> [(\"a\",1), (\"b\",2)]")
lis_tip1 = list((kle,vale) for kle, vale in diksyone.items())
print(lis_tip1)

print("\n\n\t\t ***************************************************\n\n")







#9- Pakouri yon lis tipl, pou w mete l sou fòm diksyonè. Ekzanp:

#               >>> [("a",1), ("b",2)]
#               >>> {"a":1, "b": 2}
print("#9- Pakouri yon lis tipl, pou w mete l sou fòm diksyonè. Ekzanp:\n\t\t >>> [(\"a\",1), (\"b\",2)]\n\t\t>>> {\"a\":1, \"b\": 2}")

dik1 = dict(lis_tip1)
print(dik1)
print("\n\n\t\t ***************************************************\n\n")


#10- Kole 2 diksyonè ansanm pou fè youn, kote si gen eleman ki gen menm kle ap konkatene valè, swivan kondisyon sa yo:

#                   -   Antye: ADISYON
#                   -   Chenn, lis, set: KONKATENASYON
#                   Rès eleman ki pa gen valè ki gen tip sa yo, pap nan nouvo diksyonè a.
print("#10- Kole 2 diksyonè ansanm pou fè youn, kote si gen eleman ki gen menm kle ap konkatene valè, swivan kondisyon sa yo:\n\t\t-   Antye: ADISYON\n\t\t-   Chenn, lis, set: KONKATENASYON\n\t\tRès eleman ki pa gen valè ki gen tip sa yo, pap nan nouvo diksyonè a.")