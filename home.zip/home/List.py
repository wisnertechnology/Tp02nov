#1- Kreye yon lis eleman ki divizib pa 2, nan entèval [0-n] enklizif
print("#1- Kreye yon lis eleman ki divizib pa 2, nan entèval [0-n] enklizif")
lis1 = []
n = 6
for i in range(n+1):
    if i%2 == 0:
        lis1.append(i)
print(lis1)
print("\n\n\t\t ***************************************************\n\n")


#2- Ou gen yon lis antye, konvèti l an yon lis chenn.
print("#2- Ou gen yon lis antye, konvèti l an yon lis chenn.")
lis1 = [str(nomb) for nomb in range(n+1)]
'''
for i in range(n+1):
    if i%2 == 0:
        lis1.append(str(i))
print(lis1)

'''
print(lis1)
print("\n\n\t\t ***************************************************\n\n")

#3- Ou gen yon lis chenn ki an miniskil, konvèti an yon lis chenn majiskil
print("#3- Ou gen yon lis chenn ki an miniskil, konvèti an yon lis chenn majiskil")
lis_chenn = ['chyen','chat','kabrit','poul','bef','kochon','chyen','poul']
lis_chenn = [vale.upper() for vale in lis_chenn]
print(lis_chenn)

print("\n\n\t\t ***************************************************\n\n")


#4- Ou gen yon lis, kreye yon nouvo lis ki fèt ak eleman ki nan endèks ki divizib pa 3 yo sèlman
print("#4- Ou gen yon lis, kreye yon nouvo lis ki fèt ak eleman ki nan endèks ki divizib pa 3 yo sèlman")
lis_div3 = []
for i in range(len(lis_chenn)):
    if i%3 == 0:
        lis_div3.append(lis_chenn[i]) 
print(lis_div3)        
print("\n\n\t\t ***************************************************\n\n")


#5- Ou gen lis eleman, kreye yon nouvo lis ki gen chak 3 eleman yo gwoupe anndan yon tipl. Ekzanp:
        #                 [1,2,3,4,5,6,7,8,9] => [(1,2,3), (4,5,6), (7,8,9)]
print("#5- Ou gen lis eleman, kreye yon nouvo lis ki gen chak 3 eleman yo gwoupe anndan yon tipl. Ekzanp:\n\t\t[1,2,3,4,5,6,7,8,9] => [(1,2,3), (4,5,6), (7,8,9)]")
nouvo_lis = []
for i in range(0, len(lis_chenn),3):
    tip = tuple(lis_chenn[i:i+3])
    nouvo_lis.append(tip)
    
print(nouvo_lis)    
print("\n\n\t\t ***************************************************\n\n")


#6- Ou gen yon lis, ki gen yon pakèt eleman ki repete. Konvèti l an yon lis, ki pa gen okenn doublon.
print("#6- Ou gen yon lis, ki gen yon pakèt eleman ki repete. Konvèti l an yon lis, ki pa gen okenn doublon.")
lis_san_doublon = list(set(lis_chenn))
print(lis_san_doublon)
print("\n\n\t\t ***************************************************\n\n")


#7- Ou gen 2 lis. Kreye yon nouvo lis, ki genyen sèlman eleman komen ant 2 lis yo.
print("#7- Ou gen 2 lis. Kreye yon nouvo lis, ki genyen sèlman eleman komen ant 2 lis yo.")

lis1 = ['pierre', 'andre','jean','philipe','andre']
lis2 = ['bathelmie','abraham','jean','philipe']
lis_enteseksyon = list(set(lis1) & set(lis2))
print(lis_enteseksyon)
print("\n\n\t\t ***************************************************\n\n")



#8- Ou gen 2 lis. Kreye yon nouvo lis, ki genyen sèlman eleman distenge ant 2 lis yo.
print("#8- Ou gen 2 lis. Kreye yon nouvo lis, ki genyen sèlman eleman distenge ant 2 lis yo.")
lis_diferans = list(set(lis1) ^ set(lis2))
print(lis_diferans)
print("\n\n\t\t ***************************************************\n\n")


#9- Ou gen yon diksyonè. Kreye yon nouvo lis ak kle yo sèlman, epi yon lòt ak valè yo sèlman.
print("#9- Ou gen yon diksyonè. Kreye yon nouvo lis ak kle yo sèlman, epi yon lòt ak valè yo sèlman.")
diksyone = {"prenon":"wisner", "pi":3.14, "non":"Aurelus", "aj":32}
lis_kle = list(diksyone.keys())
lis_vale = list(diksyone.values())

print(lis_kle)
print(lis_vale)
print("\n\n\t\t ***************************************************\n\n")


#10- Reyini 3 lis ansanm, san okenn doublon.
print("#10- Reyini 3 lis ansanm, san okenn doublon.")
reyinyon_lis = list(set(lis1 + lis2 + lis_vale))
print(reyinyon_lis)