#coding:utf-8
import random

#1- nan yon chenn karakte mete tout karakte yo an miniskil
print("#1- nan yon chenn karakte mete tout karakte yo an miniskil")
chenn = input("\t\t\tekri yon bgy silvouple ::\n")
chenn.lower()
print(chenn)

#2 Nan yon chenn karakte koupe chenn nan tout kote ki gen espas. epi afiche yon lis ki gen chak eleman yo
print("#2 Nan yon chenn karakte koupe chenn nan tout kote ki gen espas. epi afiche yon lis ki gen chak eleman yo")
lis_eleman = chenn.split(" ")
print(lis_eleman)
print("\n\n\n")

#3- nan yon chenn karakte mete tout premye let chak mo an majiskil
print("#3- nan yon chenn karakte mete tout premye let chak mo an majiskil")
print(chenn.title())
print("\n\n\n")

#4- nan yon chenn karakte, rekipere premye let chak mo. Epi afiche yon nouvo chenn ak tout inisyal sa yo
print("#4- nan yon chenn karakte, rekipere premye let chak mo. Epi afiche yon nouvo chenn ak tout inisyal sa yo")
nouvo_mo=''
for mo in chenn.split():
    nouvo_mo += mo[0]
print(nouvo_mo)
print("\n\n\n")


#5- Ranplase tout karaktè "a" ki nan yon chenn pa "@"
print("#5- Ranplase tout karaktè \"a\" ki nan yon chenn pa \"@\"")
ranplase = chenn.replace("a","@")
print(ranplase)
print("\n\n\n")

#6- Mete yon chenn karaktè devan dèyè, answit mete l an majiskil.
print("#6- Mete yon chenn karaktè devan dèyè, answit mete l an majiskil.")
devandeye = ''
longe_chenn =len(chenn)
print(longe_chenn)
for i in range(longe_chenn-1, -1, -1):
    devandeye +=chenn [i]

print(devandeye.upper())
print("\n\n\n")

#7- Afiche endeks premye karaktè "a" ki nan yon chenn.
print("#7- Afiche endeks premye karaktè \"a\" ki nan yon chenn.")
chenn = input("\t\t\tekri yon bgy silvouple ::\n")
chenn.lower() 
if "a" in chenn:
    print(chenn.index("a"))
else:
    print("a pa nan chenn nan")
print("\n\n\n")

#8- Afiche total tout endeks karaktè "a" ki nan yon chenn (Kit se a majiskil oubyen miniskil).
print("#8- Afiche total tout endeks karaktè \"a\" ki nan yon chenn (Kit se a majiskil oubyen miniskil).")
konteAa = 0
for i in range(len(chenn)):
    if chenn[i].lower() == "a":
        konteAa +=1 
print("a(A) twouvel {} fwa nan chenn nan".format(konteAa))
print(konteAa)
print("\n\n\n")

#9- Kreye yon lis ki gen endeks tout karaktè "a" ki nan yon chenn (Sèlman a miniskil)
print("#9- Kreye yon lis ki gen endeks tout karaktè \"a\" ki nan yon chenn (Sèlman a miniskil)")
lis_endis_a = []
for i in range(len(chenn)):
    if chenn[i] == "a":
        lis_endis_a.append(i)#nou fe apel avek metod apend lan pou ajoute yon nouvo eleman na lis nou an pou nou
print(lis_endis_a)
print("\n\n\n")

#10- Retire tout espas ki nan yon chenn, epi kole chenn sa ak kantite karaktè li genyen (Pa kontwole espas yo).
print("#10- Retire tout espas ki nan yon chenn, epi kole chenn sa ak kantite karaktè li genyen (Pa kontwole espas yo).")
retire_espas =chenn.replace(" ", "")
print(retire_espas+str(longe_chenn))